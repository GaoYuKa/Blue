﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BAccurate.Models.Test
{
    public class QueryTest
    {
        public string Name { get; set; }
    }
}
