 
declare interface Window {
    koeasyui:any,
    ace:any,
    posApiUrl:any,
    extends:any,
    webConfig:any,
    mcgs:any,
    _:any
}
declare interface KnockoutStatic{
    mapping:any
}