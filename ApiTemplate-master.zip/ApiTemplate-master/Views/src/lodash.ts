
export const _ = window._;